# Learn Maltese Alphabet — Android

A beginner-friendly native Android app showing all 30 Maltese alphabet letters, example words, and approximate sound guides.

## Build and install
1. Open this folder in **Android Studio** (with Android SDK 35 and JDK 17).
2. Allow Gradle to sync.
3. Connect an Android phone with USB debugging enabled and press **Run**, or choose **Build > Build APK(s)** to create an installable APK.

## Audio limitation
The buttons use Android's built-in TextToSpeech with the `mt-MT` locale. **Many Android phones do not have a Maltese voice installed**, and audio will be unavailable in that case. The app displays this clearly instead of playing misleading English-language speech. For dependable pronunciation on all devices, the next version should bundle recordings from a native Maltese speaker (one file per letter and example word).

## Notes
The English sound cues are approximations, not phonetic transcriptions. Some Maltese letters (notably Għ, H, and Q) have context-sensitive pronunciations. This is an educational starter app, not a substitute for native-speaker recordings.
