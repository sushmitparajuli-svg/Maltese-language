package com.example.maltialphabet;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String[] LETTERS = {"A","B","Ċ","D","E","F","Ġ","G","Għ","H","Ħ","I","Ie","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Ż","Z"};
    private static final String[] WORDS = {"ara","bieb","ċirasa","dar","elf","fjura","ġelat","gallarija","għasfur","hemm","ħobż","ilma","ieħor","jum","kelb","lumi","mara","nar","omm","papra","qattus","raġel","sajf","tifel","uffiċċju","vapur","weraq","xemx","żebra","zalzett"};
    private static final String[] NOTES = {"a as in father","b sound","ch as in chair","d sound","short e sound","f sound","j as in jam","hard g as in go","often lengthens or changes the preceding vowel","usually silent in modern Maltese","strong breathy h, like Arabic ḥ","i as in machine","ie is one letter; a vowel sound","y as in yes","k sound","l sound","m sound","n sound","o sound","p sound","deep q / glottal stop","rolled or tapped r","s sound","t sound","u as in rule","v sound","w sound","sh as in ship","z as in zebra","ts as in cats"};
    private TextToSpeech tts;
    private boolean speechReady = false;
    private TextView title, word, note, status;
    private int selected = 0;
    private final int navy = Color.rgb(22,40,70), blue = Color.rgb(20,104,170);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int support = tts.setLanguage(new Locale("mt", "MT"));
                speechReady = support != TextToSpeech.LANG_MISSING_DATA && support != TextToSpeech.LANG_NOT_SUPPORTED;
                if (status != null) status.setText(speechReady ? "Maltese speech available ✓" : "Maltese voice not installed. Install a Maltese TTS voice in Android settings, if your speech engine offers one.");
            } else if (status != null) status.setText("Speech engine unavailable on this device.");
        });
        draw();
    }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView label(String value, int size, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); return t;
    }
    private void speak(String value) {
        if (speechReady) tts.speak(value, TextToSpeech.QUEUE_FLUSH, null, "maltese_letter");
        else Toast.makeText(this, "Maltese voice not available on this phone", Toast.LENGTH_LONG).show();
    }
    private void select(int i) {
        selected = i;
        title.setText(LETTERS[i]);
        word.setText("Example: " + WORDS[i]);
        note.setText("Sound guide: " + NOTES[i] + "\n(Approximate English cue)");
    }
    private void draw() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20, 25, 20, 18); root.setBackgroundColor(Color.rgb(246,249,253));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.addView(root); setContentView(scroll);
        TextView header = label("Il-Alfabett Malti 🇲🇹", 27, navy); header.setTypeface(null, Typeface.BOLD); root.addView(header);
        TextView sub = label("Tap a letter to learn its sound", 15, blue); root.addView(sub);
        title = label("A", 90, navy); title.setTypeface(null, Typeface.BOLD); root.addView(title);
        word = label("", 23, navy); root.addView(word);
        note = label("", 16, Color.DKGRAY); note.setPadding(0, 12, 0, 15); root.addView(note);
        Button play = new Button(this); play.setText("🔊  Hear letter"); play.setTextSize(18); play.setTextColor(Color.WHITE); play.setBackground(bg(blue, 24)); root.addView(play, new LinearLayout.LayoutParams(-1, 65));
        play.setOnClickListener(v -> speak(LETTERS[selected]));
        Button example = new Button(this); example.setText("🔊  Hear example word"); root.addView(example); example.setOnClickListener(v -> speak(WORDS[selected]));
        status = label("Checking Maltese speech support…", 13, Color.DKGRAY); status.setPadding(0, 10, 0, 15); root.addView(status);
        TextView all = label("Choose a letter", 21, navy); all.setTypeface(null, Typeface.BOLD); root.addView(all);
        GridLayout grid = new GridLayout(this); grid.setColumnCount(5); root.addView(grid);
        for (int i = 0; i < LETTERS.length; i++) {
            final int index = i;
            TextView b = label(LETTERS[i], 21, Color.WHITE); b.setTypeface(null, Typeface.BOLD); b.setBackground(bg(blue, 18));
            GridLayout.LayoutParams p = new GridLayout.LayoutParams(); p.width = 0; p.height = 62; p.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); p.setMargins(3, 3, 3, 3); grid.addView(b,p);
            b.setOnClickListener(v -> select(index));
        }
        TextView foot = label("30 letters • Għ and Ie each count as one letter.\nSpeech requires a Maltese-capable Android TTS voice.", 13, Color.GRAY); foot.setPadding(0,20,0,0); root.addView(foot);
        select(0);
    }
    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
}
